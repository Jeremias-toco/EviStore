package com.example.evistore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
